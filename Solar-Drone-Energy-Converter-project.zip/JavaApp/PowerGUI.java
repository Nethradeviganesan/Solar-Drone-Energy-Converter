import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;

public class PowerGUI {
    public static void launchGUI() {
        JFrame frame = new JFrame("Solar Power Monitor");
        JLabel label = new JLabel("Solar Voltage: -- V", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 24));
        frame.add(label);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Simulate voltage updates every second
        Timer timer = new Timer();
        Random rand = new Random();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                double voltage = 3.0 + (rand.nextDouble() * 1.5); // Simulated 3.0V - 4.5V
                label.setText(String.format("Solar Voltage: %.2f V", voltage));
            }
        }, 0, 1000);
    }
}
