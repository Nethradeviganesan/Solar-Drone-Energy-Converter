# Solar Drone Energy Converter

This project demonstrates a basic solar energy converter and monitor system for drone applications.

## Components:
- Solar Panel
- Arduino (or ESP32)
- Java-based GUI for monitoring voltage

## Features:
- Monitors real-time voltage from solar panel
- Displays data on a desktop GUI
- Logs serial data from Arduino
